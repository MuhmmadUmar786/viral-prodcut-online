const functions = require("firebase-functions");
var admin = require("firebase-admin");
var serviceAccount = require("./key9.json");
let Parser = require("rss-parser");
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://workalert-e5129.firebaseio.com",
});

exports.scheduledFunction = functions.pubsub
  .schedule("every 5 minutes")
  .onRun(async (context) => {
    console.log("This will be run every 5 minutes!");
    var db = admin.firestore();
    const fcm = admin.messaging();
    var Query = db.collection("main").get();
    var listOfDocs = (await Query).docs;
    for (var i = 0; i < listOfDocs.length; i++) {
      var doc = listOfDocs[i];
      var data = doc.data();
      var ischange = false;
      let newkeywordslist = [];
      if (data != undefined) {
        var keywordslist = data["keywords"];
        var fcmtoken = data["fcm"];
        if (keywordslist != undefined) {
          for (var j = 0; j < keywordslist.length; j++) {
            var feeslink = keywordslist[j]["rss"];
            var lastJobTime = new Date(
              keywordslist[j]["lastjobtime"] == null
                ? "Mon, 23 Nov 2000 10:11:55 +0000"
                : keywordslist[j]["lastjobtime"]
            );
            var keyword = keywordslist[j]["keyword"];
            let parser = new Parser();
            await (async () => {
              try {
                let feed = await parser.parseURL(feeslink);
                let date = feed.items[0].pubDate;
                var firstJobTime = new Date(date).getTime();
                if (firstJobTime > lastJobTime) {
                  console.log("came till here");
                  ischange = true;
                  newkeywordslist.push({
                    keyword: keyword,
                    rss: feeslink,
                    lastjobtime: date,
                  });
                } else {
                  newkeywordslist.push(keywordslist[j]);
                }
              } catch (err) {
                //
              }
            })();
          }
        }
      }
      if (ischange) {
        var payload = {
          notification: {
            title: "WORK-ALERT",
            body: "You have 1 new job",
          },
        };
        try {
          var message = fcm.sendToDevice(fcmtoken, payload);
        } catch (err) {
          console.log(err);
        }
        db.collection("main").doc(doc.id).update({
          keywords: newkeywordslist,
        });
      }
    }
    return null;
  });

exports.NotiFication = functions.https.onRequest(async (req, response) => {
  var db = admin.firestore();
  const fcm = admin.messaging();
  var Query = db.collection("main").get();
  var listOfDocs = (await Query).docs;
  for (var i = 0; i < listOfDocs.length; i++) {
    var doc = listOfDocs[i];
    var data = doc.data();
    var ischange = false;
    let newkeywordslist = [];
    if (data != undefined) {
      var keywordslist = data["keywords"];
      var fcmtoken = data["fcm"];
      if (keywordslist != undefined) {
        for (var j = 0; j < keywordslist.length; j++) {
          var feeslink = keywordslist[j]["rss"];
          var lastJobTime = new Date(
            keywordslist[j]["lastjobtime"] == null
              ? "Mon, 23 Nov 2000 10:11:55 +0000"
              : keywordslist[j]["lastjobtime"]
          );
          var keyword = keywordslist[j]["keyword"];
          let parser = new Parser();
          await (async () => {
            try {
              let feed = await parser.parseURL(feeslink);
              let date = feed.items[0].pubDate;
              var firstJobTime = new Date(date).getTime();
              if (firstJobTime > lastJobTime) {
                console.log("came till here");
                ischange = true;
                newkeywordslist.push({
                  keyword: keyword,
                  rss: feeslink,
                  lastjobtime: date,
                });
              } else {
                newkeywordslist.push(keywordslist[j]);
              }
            } catch (err) {
              // console.log(err);
            }
          })();
        }
      }
    }
    if (ischange) {
      var payload = {
        notification: {
          title: "WORK-ALERT",
          body: "You have 1 new job",
        },
      };
      try {
        var message = fcm.sendToDevice(fcmtoken, payload);
      } catch (err) {
        console.log(err);
      }
      db.collection("main").doc(doc.id).update({
        keywords: newkeywordslist,
      });
    }
  }
  response.send("DONE");
});

// exports.notification = functions.https.onRequest(async (req, response) => {
//   var db = admin.firestore();
//   const fcm = admin.messaging();
//   var Query = db.collection("main").get();
//   var listOfDocs = (await Query).docs;
//   for (var i = 0; i < listOfDocs.length; i++) {
//     var doc = listOfDocs[i];
//     var data = doc.data();
//     var ischange = false;
//     let newkeywordslist = [];
//     if (data != undefined) {
//       var keywordslist = data["keywords"];
//       var fcmtoken = data["fcm"];
//       if (keywordslist != undefined) {
//         for (var j = 0; j < keywordslist.length; j++) {
//           var feeslink = keywordslist[j]["rss"];
//           var lastJobTime =
//             new Date(
//               keywordslist[j]["lastjobtime"] ??
//                 "Mon, 23 Nov 2000 10:11:55 +0000"
//             ) ?? 0;
//           var keyword = keywordslist[j]["keyword"];
//           let parser = new Parser();
//           await (async () => {
//             let feed = await parser.parseURL(feeslink);
//             let date = feed.items[0].pubDate;
//             var firstJobTime = new Date(date).getTime();
//             if (firstJobTime > lastJobTime) {
//               console.log("came till here");
//               ischange = true;
//               newkeywordslist.push({
//                 keyword: keyword,
//                 rss: feeslink,
//                 lastjobtime: date,
//               });
//             } else {
//               newkeywordslist.push(keywordslist[j]);
//             }
//           })();
//         }
//       }
//     }
//     if (ischange) {
//       var payload = {
//         notification: {
//           title: "WORK-ALERT",
//           body: "You have 1 new job",
//         },
//       };
//       try {
//         var message = fcm.sendToDevice(fcmtoken, payload);
//       } catch (err) {
//         console.log(err);
//       }

//       db.collection("main").doc(doc.id).update({
//         keywords: newkeywordslist,
//       });
//     }
//   }
//   response.send("done");
// });
// // function jobPostingTime(rawdate) {
//   if (rawdate.length == 5) {
//     var date = parseInt(rawdate[0]);
//     var year = parseInt(rawdate[2]);
//     var rawtime = rawdate[3].split(":");
//     var hour = parseInt(rawtime[0]);
//     var min = parseInt(rawtime[1]);
//       var sec = parseInt(rawtime[2]);
//       var d = new Date();
//       d.setDate(); //Set the day as a number (1-31)
//       d.setFullYear(); //Set the year (optionally month and day)
//       d.setHours(); //Set the hour (0-23)
//       d.setMilliseconds(); //Set the milliseconds (0-999)
//       d.setMinutes(); //Set the minutes (0-59)
//       d.setMonth(); //Set the month (0-11)
//       d.setSeconds();
//   }
// }
//   request(
//     "https://www.upwork.com/ab/feed/topics/rss?securityToken=8baed4433e9040ccc9eee5570e944087950814ad4695ac5fbf241c383a993f793a516ce4abc1902a408aa4e7588438e643885947180a78b5edaa9e7364d48799&userUid=1286150873466073088&orgUid=1286150873470267393",
//     function (error, respo, body) {
//       if (error) {
//         response.end();
//       }
//       if (respo.statusCode == 200) {
//         const root = html.parse(body);
//         var items = root.querySelectorAll("channel");
//         console.log(items[0].querySelectorAll("pubDate")[0].rawText);
//         response.send(items[0].querySelectorAll("pubDate")[0].toString());
//       }
//     }
//   );
