import 'dart:ui';
import 'package:flutter_test/flutter_test.dart';
import 'package:workalert/src/services/api.dart';

void main() {
  test("Api tests", () async {
    Api api = Api();
    var loginData =
        await api.login(email: 'test@test.com', password: "password");
    print(loginData);
  });
}
