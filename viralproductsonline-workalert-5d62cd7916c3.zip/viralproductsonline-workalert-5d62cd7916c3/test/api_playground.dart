import 'package:workalert/src/services/api.dart';

main(List<String> args) async {
  Api api = Api();
    var loginData =
        await api.login(email: 'test@test.com', password: "password");
    print(loginData);
}