import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import 'package:momentum/momentum.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:workalert/src/common/colors.dart';
import 'package:workalert/src/components/keywords/index.dart';

class AddKeyWord extends StatefulWidget {
  @override
  _AddKeyWordState createState() => _AddKeyWordState();
}

class _AddKeyWordState extends State<AddKeyWord> with RelativeScale {
  TextEditingController _keywordController;
  TextEditingController _urlController;
  final _formKey = GlobalKey<FormState>();

  @override
  void didChangeDependencies() {
    initRelativeScaler(context);
    super.didChangeDependencies();
  }

  @override
  void initState() {
    _keywordController = TextEditingController();
    _urlController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(sy(18.0), 0, sy(18.0), 0),
      child: Container(
        child: Form(
          key: _formKey,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 2,
                child: TextFormField(
                  controller: _keywordController,
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Please enter\nkeyword';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    fillColor: Color(0xFF0D0D0D),
                    filled: true,
                    hintText: "Keyword",
                    hintStyle: TextStyle(color: Colors.white24),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey[800]),
                    ),
                    border: OutlineInputBorder(
                      borderSide: BorderSide(),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 3,
                child: TextFormField(
                  controller: _urlController,
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Please enter some text';
                    }

                    bool _validURL = Uri.parse(value).isAbsolute;

                    if (!_validURL) {
                      return 'Invalid URL';
                    }

                    if (!value.contains("upwork.com")) {
                      return 'Invalid Upwork RSS URL';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    fillColor: Color(0xFF0D0D0D),
                    filled: true,
                    hintText: "Upwork RSS Link",
                    errorMaxLines: 2,
                    hintStyle: TextStyle(color: Colors.white24),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[800])),
                    border: OutlineInputBorder(borderSide: BorderSide()),
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Expanded(
                flex: 1,
                child: Container(
                  height: screenHeight * 0.07,
                  child: FlatButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    onPressed: () async {
                      if (_formKey.currentState.validate()) {
                        var controller =
                            Momentum.controller<KeywordsController>(context);
                        var name = _keywordController.text.trim();
                        var url = _urlController.text.trim();
                        await controller.postKeyword(name: name, url: url);
                        _keywordController.clear();
                        _urlController.clear();
                        // Flushbar(
                        //   message: "Processing",
                        // )..show(
                        //     context,
                        //   );
                        // router.Router.goto(context, Home);
                      }
                      print("adding keyword");
                    },
                    color: waGrey,
                    child: Icon(Icons.add, color: waGreen),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
