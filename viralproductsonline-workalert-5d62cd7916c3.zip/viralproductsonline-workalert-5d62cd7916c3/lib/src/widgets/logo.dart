import 'package:flutter/material.dart';
import 'package:workalert/src/common/colors.dart';

class Logo extends StatelessWidget {
  final double fontSize;

  const Logo({Key key, this.fontSize}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
          style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.bold),
          children: [
            TextSpan(text: "Work", style: TextStyle(color: waGreen)),
            TextSpan(text: "Alert"),
          ]),
    );
  }
}
