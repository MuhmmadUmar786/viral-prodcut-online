import 'package:firebase_admob/firebase_admob.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:momentum/momentum.dart';
import 'package:momentum/src/momentum_router.dart' as router;
import 'package:relative_scale/relative_scale.dart';
import "dart:io" show Platform;
import 'package:workalert/src/common/colors.dart';
import 'package:workalert/src/components/job/job.controller.dart';
import 'package:workalert/src/components/keywords/index.dart';
import 'package:workalert/src/components/rss/index.dart';
import 'package:workalert/src/data/plan_data.dart';
import 'package:workalert/src/pages/index.dart';
import 'package:workalert/src/services/jobs_services.dart';
import 'package:workalert/src/services/notificationplugin.dart';

class KeyWord extends StatefulWidget {
  final String name;
  final String count;
  final Keyword keyword;
  const KeyWord({
    Key key,
    this.name,
    this.count,
    this.keyword,
  }) : super(key: key);
  @override
  _KeyWordState createState() => _KeyWordState();
}

class _KeyWordState extends State<KeyWord> with RelativeScale {
  @override
  void didChangeDependencies() {
    initRelativeScaler(context);
    super.didChangeDependencies();
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {});

    super.initState();
  }

  static const MobileAdTargetingInfo targetingInfo = MobileAdTargetingInfo(
    testDevices: null,
    childDirected: true,
    nonPersonalizedAds: false,
  );
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        try {
          await Firebase.initializeApp();
          await FirebaseAdMob.instance.initialize(
              appId: Platform.isAndroid
                  ? "ca-app-pub-8791277208325190~1044053001"
                  : "ca-app-pub-8791277208325190~4728464374");
          await RewardedVideoAd.instance.load(
            adUnitId: "ca-app-pub-8791277208325190/1113769951",
            targetingInfo: targetingInfo,
          );
          await RewardedVideoAd.instance.show();
        } catch (err) {
          print(err);
        }

        var controller = Momentum.controller<JobController>(context);
        var rsscontroller = Momentum.controller<RssController>(context);
        rsscontroller.updateCount(widget.name, int.parse(widget.count ?? "0"));
        controller.model.update(
          currentWord: widget.name,
          newJobCount: int.parse(
            widget.count ?? "0",
          ),
        );
        router.Router.goto(
          context,
          Jobs,
        );
      },
      child: Padding(
        padding: EdgeInsets.fromLTRB(sy(18.0), 0, sy(18.0), 0),
        child: Container(
          height: screenHeight * 0.08,
          decoration: BoxDecoration(
              color: waGrey, borderRadius: BorderRadius.circular(8)),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: IconButton(
                  splashColor: Colors.transparent,
                  tooltip: "Delete this Keyword",
                  icon: Icon(
                    Icons.delete,
                    color: waGreen,
                  ),
                  onPressed: () async {
                    var controller =
                        Momentum.controller<KeywordsController>(context);
                    await controller.deleteKeyword(id: widget.keyword.id);
                    //  JobService js = JobService();
                    //await js.init();
                    //await js.deleteJobs("Flutter");
                  },
                ),
              ),
              Expanded(
                flex: 2,
                child: Text(
                  "Keyword",
                  style: TextStyle(color: Colors.white),
                ),
              ),
              Expanded(
                flex: 2,
                child: Text(
                  widget.name ?? '',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(18.0),
                child: Container(
                  width: sy(14),
                  height: sy(14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    color: waGreen.withOpacity(0.2),
                  ),
                  child: Center(
                    child: Text(
                      widget.count ?? '0',
                      style: TextStyle(color: waGreen, fontSize: sy(8)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
