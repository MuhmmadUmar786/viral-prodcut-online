
import 'package:flutter/material.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:workalert/src/common/colors.dart';

class ReferListItem extends StatefulWidget {
  final String title;
  final Widget child;

  const ReferListItem({Key key, this.title, this.child}) : super(key: key);
  @override
  _ReferListItemState createState() => _ReferListItemState();
}

class _ReferListItemState extends State<ReferListItem> with RelativeScale {
  @override
  void didChangeDependencies() {
    initRelativeScaler(context);
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(sx(20), sx(5), sx(20), sx(5)),
      child: Row(
        children: [
          Expanded(
            child: Card(
              color: Colors.white.withOpacity(0.06),
              elevation: 8,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(
                    color: Colors.white24,
                  )),
              borderOnForeground: true,
              child: Padding(
                padding: EdgeInsets.fromLTRB(sy(8), sy(12), sy(8), sy(12)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.title ?? '',
                      style: TextStyle(color: waGreen),
                    ),
                    widget.child
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
