import 'package:momentum/momentum.dart';
import 'package:workalert/src/data/index.dart';

import 'index.dart';

class KeywordsModel extends MomentumModel<KeywordsController> {
  KeywordsModel(KeywordsController controller, {this.keywordsAndPlanData, this.isLoading})
      : super(controller);

  final KeywordsAndPlanData keywordsAndPlanData;
  final bool isLoading;

  @override
  void update({
    KeywordsAndPlanData keywordsAndPlanData,
    bool isLoading,
  }) {
    KeywordsModel(
      controller,
      keywordsAndPlanData: keywordsAndPlanData ?? this.keywordsAndPlanData,
      isLoading: isLoading ?? this.isLoading,
    ).updateMomentum();
  }
}
