import 'package:flutter/foundation.dart';
import 'package:momentum/momentum.dart';
import 'package:workalert/src/components/auth/index.dart';
import 'package:workalert/src/services/api.dart';

import 'index.dart';

class KeywordsController extends MomentumController<KeywordsModel> {
  @override
  KeywordsModel init() {
    return KeywordsModel(
      this,
      isLoading: false,
    );
  }

  Future getKeyWords() async {
    var authController = dependOn<AuthController>();
    var authModel = authController.model;
    var api = getService<Api>();
    model.update(isLoading: true);
    try {
      var data = await api.getKeyWords(token: authModel.token);
      model.update(
        keywordsAndPlanData: data,
      );
      model.update(isLoading: false);
      return true;
    } catch (e) {
      print(e?.message?.statusCode);
      print(e?.message?.body);

      model.update(isLoading: false);

      return false;
    }
  }

  Future postKeyword({@required String name, @required String url}) async {
    var authController = dependOn<AuthController>();
    var authModel = authController.model;
    var api = getService<Api>();
    try {
      await api.storeKeyword(token: authModel.token, keyword: name, rss: url);
      await getKeyWords();
      return true;
    } catch (e) {
      print(e.message.statusCode);
      print(e.message.body);
      return false;
    }
  }

  Future deleteKeyword({@required int id}) async {
    var authController = dependOn<AuthController>();
    var authModel = authController.model;
    var api = getService<Api>();
    try {
      await api.deleteWord(token: authModel.token, id: id);
      await getKeyWords();
      return true;
    } catch (e) {
      print(e.message.statusCode);
      print(e.message.body);
      return false;
    }
  }
}
