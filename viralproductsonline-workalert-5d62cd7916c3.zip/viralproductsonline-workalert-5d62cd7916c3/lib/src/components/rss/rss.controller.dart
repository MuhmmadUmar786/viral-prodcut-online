import 'dart:async';

import 'package:momentum/momentum.dart';
import 'package:webfeed/domain/rss_feed.dart';
import 'package:webfeed/domain/rss_item.dart';
import 'package:http/http.dart' as http;
import 'package:workalert/src/data/job.dart';
import 'package:workalert/src/services/TimeCalulator.dart';
import 'package:workalert/src/services/client_db.dart';
import 'index.dart';

class RssController extends MomentumController<RssModel> {
  @override
  RssModel init() {
    return RssModel(
      this,
      jobsmap: {},
      keywords: {},
      itemCount: {},
    );
  }

  Future startFetching(Map<String, String> words) async {
    model.timer?.cancel();
    var timer = Timer.periodic(
      Duration(minutes: 1),
      (timer) async {
        var keywords = words.keys.toList();
        var jobsmap = model.jobsmap;
        var itemCount = model.itemCount;

        for (var keyword in keywords) {
          List<Jobs> newJobs = [];
          print("printinh $keyword");
          var items = await getData(words[keyword]);
          for (var item in items) {
            try {
              jobsmap[keyword].firstWhere((job) => job.title == item.title);
            } on StateError {
              newJobs.add(
                Jobs(
                    content: item.content.value,
                    keyword: keyword,
                    title: item.title,
                    url: words[keyword]),
              );
              itemCount[keyword] =
                  (itemCount[keyword] != null ? itemCount[keyword] : 0) + 1;
            }
          }
          jobsmap[keyword].insertAll(0, newJobs);
        }

        model.update(jobsmap: jobsmap, keywords: words, itemCount: itemCount);
        print("updated jobs");
      },
    );
    model.update(timer: timer);
  }

  Future forceUpdateJobs(Map<String, String> words) async {
    var jobsmap = model.jobsmap;
    var itemCount = model.itemCount;
    var keywords = words.keys.toList();
    for (var keyword in keywords) {
      List<Jobs> newJobs = [];
      var items = await getData(words[keyword]);
      for (var item in items) {
        try {
          if (jobsmap[keyword] == null) {
            jobsmap[keyword] = [];
          } else {
            (jobsmap[keyword]).firstWhere((job) => job.title == item.title);
          }
        } on StateError {
          newJobs.add(
            Jobs(
                content: item.content.value,
                keyword: keyword,
                title: item.title,
                url: words[keyword]),
          );
          itemCount[keyword] =
              (itemCount[keyword] != null ? itemCount[keyword] : 0) + 1;
        }
      }
      jobsmap[keyword].insertAll(0, newJobs);
    }

    model.update(jobsmap: jobsmap, keywords: words, itemCount: itemCount);
  }

  void updateCount(String name, int count) {
    var itemCount = model.itemCount;
    itemCount.update(name, (value) => count, ifAbsent: () {
      return 0;
    });
    model.update(itemCount: itemCount);
  }

  Future<List<RssItem>> getData(String url) async {
    http.Response response = await http.get(url);
    if (response.statusCode == 200) {
      try {
        var rssFeed = RssFeed.parse(response.body);
        var items = rssFeed.items;
        return items;
      } catch (err) {
        return [];
      }
    } else {
      return [];
    }
  }
}
