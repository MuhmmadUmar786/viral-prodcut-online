import 'dart:async';

import 'package:momentum/momentum.dart';
import 'package:workalert/src/data/index.dart';

import 'index.dart';

class RssModel extends MomentumModel<RssController> {
  RssModel(RssController controller,
      {this.jobsmap, this.keywords, this.timer, this.itemCount})
      : super(controller);

  final Map<String, List<Jobs>> jobsmap;
  final Map<String, String> keywords;
  final Timer timer;
  final Map<String, int> itemCount;

  @override
  void update(
      {Map<String, List<Jobs>> jobsmap,
      Map<String, String> keywords,
      Timer timer,
      Map<String, int> itemCount}) {
    RssModel(
      controller,
      jobsmap: jobsmap ?? this.jobsmap,
      keywords: keywords ?? this.keywords,
      timer: timer ?? this.timer,
      itemCount: itemCount ?? this.itemCount,
    ).updateMomentum();
  }

//   Map<String, dynamic> toJson() {
//     return {
//       'jobs': jobsmap.map(
//         (e) => e.toJson(),
//       ).toList(),
//       'keywords': keywords,
//       'itemCount': itemCount,
//     };
//   }

//   RssModel fromJson(Map<String, dynamic> json) {
//     if (json == null) return null;

//     return RssModel(
//       controller,
//       jobs: List<Jobs>.from(json['jobs']?.map<Jobs>((i) => Jobs.fromJson(i))),
//       keywords: Map<String, String>.from(json['keywords']),
//       itemCount: Map<String, int>.from(json['itemCount']),
//     );
//   }
}
