import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart';
import 'package:momentum/momentum.dart';
import 'package:workalert/src/components/rss/index.dart';
import 'package:workalert/src/pages/index.dart';
import 'package:workalert/src/services/api.dart';
import 'package:momentum/src/momentum_router.dart' as router;
import '../../../main.dart';
import 'index.dart';
import 'dart:convert';

class AuthController extends MomentumController<AuthModel> {
  @override
  AuthModel init() {
    return AuthModel(
      this,
      isError: false,
      isLoading: false,
    );
  }

  Future<Response> ForgetPassword(@required String email) async {
    var api = getService<Api>();
    var data = await api.forgetPassword(email: email);
    return data;
  }

  Future<bool> login(
      {@required String email, @required String password}) async {
    var api = getService<Api>();
    model.update(isLoading: true);
    try {
      var data = await api.login(email: email, password: password);
      model.update(
        email: data.email,
        password: password,
        referral: data.affiliateId,
        token: data.token,
      );
      model.update(isLoading: false);
      return true;
    } catch (e) {
      print(e.message.statusCode);
      print(e.message.body);

      model.update(isLoading: false);
      return false;
    }
  }

  Future<bool> register(
      {@required String email, @required String password, String ref}) async {
    var api = getService<Api>();

    model.update(isLoading: true);
    try {
      var data = await api.register(email: email, password: password, ref: ref);
      model.update(
        email: data.email,
        password: password,
        referral: data.affiliateId,
        token: data.token,
      );
      model.update(isLoading: false);
      return true;
    } catch (e) {
      print(e.message.statusCode);
      print(e.message.body);

      model.update(isLoading: false);
      return false;
    }
  }

  Future<bool> getUser() async {
    var api = getService<Api>();
    try {
      var data = await api.getUser(token: model.token);
      model.update(userData: data);
      return true;
    } catch (e) {
      print(e.message.statusCode);
      print(e.message.body);

      return false;
    }
  }

  Future logout(BuildContext context) async {
    try {
      print("Logged out");
    } catch (e) {}
    Momentum.resetAll(context);
    var rssController = dependOn<RssController>();
    rssController.model.timer?.cancel();
    await router.Router.resetWithContext<Landing>(context);

    Momentum.restart(context, momentum());
  }
}
