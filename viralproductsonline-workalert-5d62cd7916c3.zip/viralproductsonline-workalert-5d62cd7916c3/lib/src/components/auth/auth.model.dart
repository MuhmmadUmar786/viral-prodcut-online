import 'package:equatable/equatable.dart';
import 'package:momentum/momentum.dart';
import 'package:workalert/src/data/index.dart';

import 'index.dart';

class AuthModel extends MomentumModel<AuthController> with EquatableMixin {
  AuthModel(
    AuthController controller, {
    this.token,
    this.email,
    this.password,
    this.referral,
    this.isError,
    this.errorMessage,
    this.isLoading,
    this.userData,
  }) : super(controller);

  final String token;
  final String email;
  final String password;
  final String referral;
  final bool isError;
  final bool isLoading;
  final String errorMessage;
  final UserData userData;

  @override
  void update(
      {String token,
      String email,
      String password,
      String referral,
      bool isError,
      String errorMessage,
      bool isLoading, 
      UserData userData,
      }) {
    AuthModel(controller,
            token: token ?? this.token,
            email: email ?? this.email,
            password: password ?? this.password,
            referral: referral ?? this.referral,
            isError: isError ?? this.isError,
            errorMessage: errorMessage ?? this.errorMessage,
            isLoading: isLoading ?? this.isLoading, 
            userData: userData ?? this.userData,
            )
        .updateMomentum();
  }

  Map<String, dynamic> toJson() {
    return {
      'token': token,
      'email': email,
      'password': password,
      'referral': referral
    };
  }

  AuthModel fromJson(Map<String, dynamic> json) {
    if (json == null) return null;

    return AuthModel(controller,
        token: json['token'],
        email: json['email'],
        password: json['password'],
        referral: json['referral']);
  }

  @override
  List<Object> get props => [
        token,
        email,
        password,
        referral,
        userData,
        errorMessage
      ];
}
