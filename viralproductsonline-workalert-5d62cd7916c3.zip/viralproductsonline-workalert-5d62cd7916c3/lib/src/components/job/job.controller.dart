import 'package:momentum/momentum.dart';

import 'index.dart';

class JobController extends MomentumController<JobModel> {
  @override
  JobModel init() {
    return JobModel(
      this,
      
    );
  }
}
