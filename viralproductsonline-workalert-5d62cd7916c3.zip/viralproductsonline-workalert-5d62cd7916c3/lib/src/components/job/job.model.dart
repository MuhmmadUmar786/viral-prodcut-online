import 'package:momentum/momentum.dart';

import 'index.dart';

class JobModel extends MomentumModel<JobController> {
  JobModel(JobController controller, {this.currentWord, this.newJobCount})
      : super(controller);
  final int newJobCount;
  final String currentWord;

  @override
  void update({String currentWord, int newJobCount}) {
    JobModel(controller,
            currentWord: currentWord ?? this.currentWord,
            newJobCount: newJobCount ?? this.newJobCount)
        .updateMomentum();
  }

  Map<String, dynamic> toJson() {
    return {
      'currentWord': currentWord,
    };
  }

  JobModel fromJson(Map<String, dynamic> map) {
    if (map == null) return null;

    return JobModel(
      controller,
      currentWord: map['currentWord'],
    );
  }
}
