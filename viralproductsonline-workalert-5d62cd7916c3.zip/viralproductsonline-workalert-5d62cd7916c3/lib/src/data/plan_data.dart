// To parse this JSON data, do
//
//     final keywordsAndPlanData = keywordsAndPlanDataFromJson(jsonString);

import 'dart:convert';

KeywordsAndPlanData keywordsAndPlanDataFromJson(String str) => KeywordsAndPlanData.fromJson(json.decode(str));

String keywordsAndPlanDataToJson(KeywordsAndPlanData data) => json.encode(data.toJson());

class KeywordsAndPlanData {
    KeywordsAndPlanData({
        this.plans,
        this.currentPlan,
        this.keywords,
    });

    List<Plan> plans;
    Plan currentPlan;
    List<Keyword> keywords;

    factory KeywordsAndPlanData.fromJson(Map<String, dynamic> json) => KeywordsAndPlanData(
        plans: json["plans"] == null ? null : List<Plan>.from(json["plans"].map((x) => Plan.fromJson(x))),
        currentPlan: json["current_plan"] == null ? null : Plan.fromJson(json["current_plan"]),
        keywords: json["keywords"] == null ? null : List<Keyword>.from(json["keywords"].map((x) => Keyword.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "plans": plans == null ? null : List<dynamic>.from(plans.map((x) => x.toJson())),
        "current_plan": currentPlan == null ? null : currentPlan.toJson(),
        "keywords": keywords == null ? null : List<dynamic>.from(keywords.map((x) => x.toJson())),
    };
}

class Plan {
    Plan({
        this.id,
        this.name,
        this.description,
        this.type,
        this.frequency,
        this.frequencyInterval,
        this.cycles,
        this.amount,
        this.currency,
        this.autoBillAmount,
        this.initialFailAmountAction,
        this.paypalPlanId,
        this.stripeProdId,
        this.stripePlanId,
        this.isFree,
        this.createdAt,
        this.updatedAt,
        this.keywordLimit,
    });

    int id;
    String name;
    String description;
    String type;
    String frequency;
    String frequencyInterval;
    String cycles;
    double amount;
    String currency;
    String autoBillAmount;
    String initialFailAmountAction;
    dynamic paypalPlanId;
    String stripeProdId;
    String stripePlanId;
    int isFree;
    DateTime createdAt;
    DateTime updatedAt;
    int keywordLimit;

    factory Plan.fromJson(Map<String, dynamic> json) => Plan(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        description: json["description"] == null ? null : json["description"],
        type: json["type"] == null ? null : json["type"],
        frequency: json["frequency"] == null ? null : json["frequency"],
        frequencyInterval: json["frequency_interval"] == null ? null : json["frequency_interval"],
        cycles: json["cycles"] == null ? null : json["cycles"],
        amount: json["amount"] == null ? null : json["amount"].toDouble(),
        currency: json["currency"] == null ? null : json["currency"],
        autoBillAmount: json["auto_bill_amount"] == null ? null : json["auto_bill_amount"],
        initialFailAmountAction: json["initial_fail_amount_action"] == null ? null : json["initial_fail_amount_action"],
        paypalPlanId: json["paypal_plan_id"],
        stripeProdId: json["stripe_prod_id"] == null ? null : json["stripe_prod_id"],
        stripePlanId: json["stripe_plan_id"] == null ? null : json["stripe_plan_id"],
        isFree: json["is_free"] == null ? null : json["is_free"],
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
        keywordLimit: json["keyword_limit"] == null ? null : json["keyword_limit"],
    );

    Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "description": description == null ? null : description,
        "type": type == null ? null : type,
        "frequency": frequency == null ? null : frequency,
        "frequency_interval": frequencyInterval == null ? null : frequencyInterval,
        "cycles": cycles == null ? null : cycles,
        "amount": amount == null ? null : amount,
        "currency": currency == null ? null : currency,
        "auto_bill_amount": autoBillAmount == null ? null : autoBillAmount,
        "initial_fail_amount_action": initialFailAmountAction == null ? null : initialFailAmountAction,
        "paypal_plan_id": paypalPlanId,
        "stripe_prod_id": stripeProdId == null ? null : stripeProdId,
        "stripe_plan_id": stripePlanId == null ? null : stripePlanId,
        "is_free": isFree == null ? null : isFree,
        "created_at": createdAt == null ? null : createdAt.toIso8601String(),
        "updated_at": updatedAt == null ? null : updatedAt.toIso8601String(),
        "keyword_limit": keywordLimit == null ? null : keywordLimit,
    };
}

class Keyword {
    Keyword({
        this.id,
        this.userId,
        this.keyword,
        this.rss,
        this.createdAt,
        this.updatedAt,
    });

    int id;
    int userId;
    String keyword;
    String rss;
    DateTime createdAt;
    DateTime updatedAt;

    factory Keyword.fromJson(Map<String, dynamic> json) => Keyword(
        id: json["id"] == null ? null : json["id"],
        userId: json["user_id"] == null ? null : json["user_id"],
        keyword: json["keyword"] == null ? null : json["keyword"],
        rss: json["rss"] == null ? null : json["rss"],
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "user_id": userId == null ? null : userId,
        "keyword": keyword == null ? null : keyword,
        "rss": rss == null ? null : rss,
        "created_at": createdAt == null ? null : createdAt.toIso8601String(),
        "updated_at": updatedAt == null ? null : updatedAt.toIso8601String(),
    };
}
