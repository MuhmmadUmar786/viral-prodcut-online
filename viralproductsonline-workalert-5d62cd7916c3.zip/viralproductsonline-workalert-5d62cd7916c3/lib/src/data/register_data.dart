// To parse this JSON data, do
//
//     final registerData = registerDataFromJson(jsonString);

import 'dart:convert';

RegisterData registerDataFromJson(String str) => RegisterData.fromJson(json.decode(str));

String registerDataToJson(RegisterData data) => json.encode(data.toJson());

class RegisterData {
    RegisterData({
        this.token,
        this.username,
        this.email,
        this.keywords,
        this.affiliateId,
        this.affiliateUrl,
        this.referredBy,
    });

    String token;
    String username;
    String email;
    int keywords;
    String affiliateId;
    String affiliateUrl;
    String referredBy;

    factory RegisterData.fromJson(Map<String, dynamic> json) => RegisterData(
        token: json["token"] == null ? null : json["token"],
        username: json["username"] == null ? null : json["username"],
        email: json["email"] == null ? null : json["email"],
        keywords: json["keywords"] == null ? null : json["keywords"],
        affiliateId: json["affiliate_id"] == null ? null : json["affiliate_id"],
        affiliateUrl: json["affiliate_url"] == null ? null : json["affiliate_url"],
        referredBy: json["referred_by"] == null ? null : json["referred_by"],
    );

    Map<String, dynamic> toJson() => {
        "token": token == null ? null : token,
        "username": username == null ? null : username,
        "email": email == null ? null : email,
        "keywords": keywords == null ? null : keywords,
        "affiliate_id": affiliateId == null ? null : affiliateId,
        "affiliate_url": affiliateUrl == null ? null : affiliateUrl,
        "referred_by": referredBy == null ? null : referredBy,
    };
}
