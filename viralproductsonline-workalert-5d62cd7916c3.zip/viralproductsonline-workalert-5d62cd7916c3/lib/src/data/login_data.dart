// To parse this JSON data, do
//
//     final loginData = loginDataFromJson(jsonString);

import 'dart:convert';

LoginData loginDataFromJson(String str) => LoginData.fromJson(json.decode(str));

String loginDataToJson(LoginData data) => json.encode(data.toJson());

class LoginData {
    LoginData({
        this.token,
        this.username,
        this.email,
        this.keywords,
        this.affiliateId,
        this.affiliateUrl,
        this.referredBy,
    });

    String token;
    String username;
    String email;
    int keywords;
    String affiliateId;
    String affiliateUrl;
    dynamic referredBy;

    factory LoginData.fromJson(Map<String, dynamic> json) => LoginData(
        token: json["token"] == null ? null : json["token"],
        username: json["username"] == null ? null : json["username"],
        email: json["email"] == null ? null : json["email"],
        keywords: json["keywords"] == null ? null : json["keywords"],
        affiliateId: json["affiliate_id"] == null ? null : json["affiliate_id"],
        affiliateUrl: json["affiliate_url"] == null ? null : json["affiliate_url"],
        referredBy: json["referred_by"],
    );

    Map<String, dynamic> toJson() => {
        "token": token == null ? null : token,
        "username": username == null ? null : username,
        "email": email == null ? null : email,
        "keywords": keywords == null ? null : keywords,
        "affiliate_id": affiliateId == null ? null : affiliateId,
        "affiliate_url": affiliateUrl == null ? null : affiliateUrl,
        "referred_by": referredBy,
    };
}
