// To parse this JSON data, do
//
//     final jobs = jobsFromJson(jsonString);

import 'dart:convert';

List<Jobs> jobsFromJson(String str) => List<Jobs>.from(json.decode(str).map((x) => Jobs.fromJson(x)));

String jobsToJson(List<Jobs> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Jobs {
    Jobs({
        this.title,
        this.titlehash,
        this.content,
        this.keyword,
        this.url,
    });

    String title;
    String titlehash;
    String content;
    String keyword;
    String url;

    factory Jobs.fromJson(Map<String, dynamic> json) => Jobs(
        title: json["title"] == null ? null : json["title"],
        titlehash: json["titlehash"] == null ? null : json["titlehash"],
        content: json["content"] == null ? null : json["content"],
        keyword: json["keyword"] == null ? null : json["keyword"],
        url: json["url"] == null ? null : json["url"],
    );

    Map<String, dynamic> toJson() => {
        "title": title == null ? null : title,
        "titlehash": titlehash == null ? null : titlehash,
        "content": content == null ? null : content,
        "keyword": keyword == null ? null : keyword,
        "url": url == null ? null : url,
    };
}
