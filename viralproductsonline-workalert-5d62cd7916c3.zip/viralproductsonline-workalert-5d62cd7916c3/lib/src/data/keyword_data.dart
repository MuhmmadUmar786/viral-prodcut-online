// To parse this JSON data, do
//
//     final keyWordData = keyWordDataFromJson(jsonString);

import 'dart:convert';

import 'package:workalert/src/data/index.dart';

KeyWordData keyWordDataFromJson(String str) => KeyWordData.fromJson(json.decode(str));

String keyWordDataToJson(KeyWordData data) => json.encode(data.toJson());

class KeyWordData {
    KeyWordData({
        this.keywords,
    });

    List<Keyword> keywords;

    factory KeyWordData.fromJson(Map<String, dynamic> json) => KeyWordData(
        keywords: json["keywords"] == null ? null : List<Keyword>.from(json["keywords"].map((x) => Keyword.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "keywords": keywords == null ? null : List<dynamic>.from(keywords.map((x) => x.toJson())),
    };
}



