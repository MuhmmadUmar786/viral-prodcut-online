// To parse this JSON data, do
//
//     final userData = userDataFromJson(jsonString);

import 'dart:convert';

UserData userDataFromJson(String str) => UserData.fromJson(json.decode(str));

String userDataToJson(UserData data) => json.encode(data.toJson());

class UserData {
    UserData({
        this.token,
        this.username,
        this.email,
        this.currentPlan,
        this.keywords,
        this.affiliateId,
        this.affiliateUrl,
        this.referredBy,
        this.referralPoints,
    });

    String token;
    String username;
    String email;
    CurrentPlan currentPlan;
    int keywords;
    String affiliateId;
    String affiliateUrl;
    String referredBy;
    int referralPoints;

    factory UserData.fromJson(Map<String, dynamic> json) => UserData(
        token: json["token"] == null ? null : json["token"],
        username: json["username"] == null ? null : json["username"],
        email: json["email"] == null ? null : json["email"],
        currentPlan: json["current_plan"] == null ? null : CurrentPlan.fromJson(json["current_plan"]),
        keywords: json["keywords"] == null ? null : json["keywords"],
        affiliateId: json["affiliate_id"] == null ? null : json["affiliate_id"],
        affiliateUrl: json["affiliate_url"] == null ? null : json["affiliate_url"],
        referredBy: json["referred_by"] == null ? null : json["referred_by"],
        referralPoints: json["referral_points"] == null ? null : json["referral_points"],
    );

    Map<String, dynamic> toJson() => {
        "token": token == null ? null : token,
        "username": username == null ? null : username,
        "email": email == null ? null : email,
        "current_plan": currentPlan == null ? null : currentPlan.toJson(),
        "keywords": keywords == null ? null : keywords,
        "affiliate_id": affiliateId == null ? null : affiliateId,
        "affiliate_url": affiliateUrl == null ? null : affiliateUrl,
        "referred_by": referredBy == null ? null : referredBy,
        "referral_points": referralPoints == null ? null : referralPoints,
    };
}

class CurrentPlan {
    CurrentPlan({
        this.id,
        this.name,
        this.description,
        this.type,
        this.frequency,
        this.frequencyInterval,
        this.cycles,
        this.amount,
        this.currency,
        this.autoBillAmount,
        this.initialFailAmountAction,
        this.paypalPlanId,
        this.stripeProdId,
        this.stripePlanId,
        this.isFree,
        this.createdAt,
        this.updatedAt,
        this.keywordLimit,
    });

    int id;
    String name;
    String description;
    String type;
    String frequency;
    String frequencyInterval;
    String cycles;
    int amount;
    String currency;
    String autoBillAmount;
    String initialFailAmountAction;
    dynamic paypalPlanId;
    String stripeProdId;
    String stripePlanId;
    int isFree;
    DateTime createdAt;
    DateTime updatedAt;
    int keywordLimit;

    factory CurrentPlan.fromJson(Map<String, dynamic> json) => CurrentPlan(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        description: json["description"] == null ? null : json["description"],
        type: json["type"] == null ? null : json["type"],
        frequency: json["frequency"] == null ? null : json["frequency"],
        frequencyInterval: json["frequency_interval"] == null ? null : json["frequency_interval"],
        cycles: json["cycles"] == null ? null : json["cycles"],
        amount: json["amount"] == null ? null : json["amount"],
        currency: json["currency"] == null ? null : json["currency"],
        autoBillAmount: json["auto_bill_amount"] == null ? null : json["auto_bill_amount"],
        initialFailAmountAction: json["initial_fail_amount_action"] == null ? null : json["initial_fail_amount_action"],
        paypalPlanId: json["paypal_plan_id"],
        stripeProdId: json["stripe_prod_id"] == null ? null : json["stripe_prod_id"],
        stripePlanId: json["stripe_plan_id"] == null ? null : json["stripe_plan_id"],
        isFree: json["is_free"] == null ? null : json["is_free"],
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
        keywordLimit: json["keyword_limit"] == null ? null : json["keyword_limit"],
    );

    Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "description": description == null ? null : description,
        "type": type == null ? null : type,
        "frequency": frequency == null ? null : frequency,
        "frequency_interval": frequencyInterval == null ? null : frequencyInterval,
        "cycles": cycles == null ? null : cycles,
        "amount": amount == null ? null : amount,
        "currency": currency == null ? null : currency,
        "auto_bill_amount": autoBillAmount == null ? null : autoBillAmount,
        "initial_fail_amount_action": initialFailAmountAction == null ? null : initialFailAmountAction,
        "paypal_plan_id": paypalPlanId,
        "stripe_prod_id": stripeProdId == null ? null : stripeProdId,
        "stripe_plan_id": stripePlanId == null ? null : stripePlanId,
        "is_free": isFree == null ? null : isFree,
        "created_at": createdAt == null ? null : createdAt.toIso8601String(),
        "updated_at": updatedAt == null ? null : updatedAt.toIso8601String(),
        "keyword_limit": keywordLimit == null ? null : keywordLimit,
    };
}
