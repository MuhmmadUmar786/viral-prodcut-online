import 'package:flutter/material.dart';
import 'package:momentum/momentum.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:workalert/src/common/colors.dart';
import 'package:workalert/src/pages/index.dart';
import 'package:workalert/src/widgets/logo.dart';
import 'package:momentum/src/momentum_router.dart' as router;

class Landing extends StatefulWidget {
  @override
  _LandingState createState() => _LandingState();
}

class _LandingState extends State<Landing> with RelativeScale {
  @override
  void didChangeDependencies() {
    initRelativeScaler(context);
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return RouterPage(
            onWillPop: () async {

        return false;
      },
          child: Scaffold(
        body: Column(
          children: [
            Expanded(
              child: Container(),
            ),
            Logo(
              fontSize: sy(30),
            ),
            Expanded(
              child: Container(),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  color: Color(0xFF0D0D0D),
                  width: screenWidth * 0.9,
                  height: screenHeight * 0.065,
                  child: OutlineButton(
                    borderSide: BorderSide(
                      color: waGreen,
                    ),
                    onPressed: () {
                      print("Login");
                      router.Router.goto(context, Login);
                    },
                    splashColor: waGreen,
                    highlightedBorderColor: Colors.white,
                    child: Text(
                      "LOGIN",
                      style: TextStyle(color: waGreen),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: sy(10),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  color: Color(0xFF0D0D0D),
                  width: screenWidth * 0.9,
                  height: screenHeight * 0.065,
                  child: FlatButton(
                    color: waGreen,
                    onPressed: () {
                      print("Register");
                      router.Router.goto(context, Register);
                    },
                    child: Text(
                      "REGISTER",
                      style: TextStyle(),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
