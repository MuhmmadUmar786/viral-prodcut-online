import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import 'package:momentum/momentum.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:workalert/src/common/colors.dart';
import 'package:momentum/src/momentum_router.dart' as router;
import 'package:workalert/src/components/auth/index.dart';
import 'package:workalert/src/widgets/logo.dart';

import 'index.dart';

class Register extends StatefulWidget {
  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> with RelativeScale {
  TextEditingController _emailController;
  TextEditingController _passwordController;
  TextEditingController _passwordConfirmController;
  TextEditingController _referralController;
  final _formKey = GlobalKey<FormState>();

  @override
  void didChangeDependencies() {
    initRelativeScaler(context);
    super.didChangeDependencies();
  }

  @override
  void initState() {
    _emailController = TextEditingController();
    _passwordController = TextEditingController();
    _passwordConfirmController = TextEditingController();
    _referralController = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _passwordConfirmController.dispose();
    _referralController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RouterPage(
      onWillPop: () async {
        router.Router.pop(context);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: waGrey,
          title: Logo(),
          actions: [
            InkWell(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Login",
                    style: TextStyle(color: waGreen),
                  ),
                ),
              ),
              onTap: () {
                router.Router.goto(context, Login);
              },
            )
          ],
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(sx(30)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.all(sx(24)),
                  child: Text(
                    "Sign Up",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: sx(24),
                    ),
                  ),
                ),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _emailController,
                        validator: (value) {
                          bool emailValid = RegExp(
                                  r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                              .hasMatch(value);
                          if (value.isEmpty) {
                            return 'Please enter some text';
                          }

                          if (!emailValid) {
                            return 'Please enter a valid Email!';
                          }
                          return null;
                        },
                        style: TextStyle(color: Colors.white),
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          fillColor: Color(0xFF0D0D0D),
                          filled: true,
                          hintText: "Email Address",
                          hintStyle: TextStyle(color: Colors.white24),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey[800])),
                          border: OutlineInputBorder(borderSide: BorderSide()),
                        ),
                      ),
                      SizedBox(
                        height: sy(12),
                      ),
                      TextFormField(
                        controller: _passwordController,
                        validator: (value) {
                          if (value.isEmpty) {
                            return 'Please enter some text';
                          }

                          if (value.length < 8) {
                            return 'Password too short!';
                          }

                          return null;
                        },
                        obscureText: true,
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          fillColor: Color(0xFF0D0D0D),
                          filled: true,
                          hintText: "Password",
                          hintStyle: TextStyle(color: Colors.white24),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey[800])),
                          border: OutlineInputBorder(borderSide: BorderSide()),
                        ),
                      ),
                      SizedBox(
                        height: sy(12),
                      ),
                      TextFormField(
                        controller: _passwordConfirmController,
                        validator: (value) {
                          if (value.isEmpty) {
                            return 'Please enter some text';
                          }

                          if (value.length < 8) {
                            return 'Password too short!';
                          }

                          if (value != _passwordController.text) {
                            return 'Passwords do not match!';
                          }

                          return null;
                        },
                        obscureText: true,
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          fillColor: Color(0xFF0D0D0D),
                          filled: true,
                          hintText: "Confirm Password",
                          hintStyle: TextStyle(color: Colors.white24),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey[800])),
                          border: OutlineInputBorder(borderSide: BorderSide()),
                        ),
                      ),
                      SizedBox(
                        height: sy(12),
                      ),
                      TextFormField(
                        controller: _referralController,
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          fillColor: Color(0xFF0D0D0D),
                          filled: true,
                          hintText: "Referral Code (optional)",
                          hintStyle: TextStyle(color: Colors.white24),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey[800])),
                          border: OutlineInputBorder(borderSide: BorderSide()),
                        ),
                      ),
                    ],
                  ),
                ),
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.center,
                //   children: [
                //     Padding(
                //       padding: EdgeInsets.all(sy(12.0)),
                //       child: InkWell(
                //         onTap: () {
                //           router.Router.goto(context, ResetPassword);
                //         },
                //         child: Text(
                //           "Forgot Password",
                //           style: TextStyle(color: waGreen),
                //         ),
                //       ),
                //     ),
                //   ],
                // ),
                SizedBox(height: sy(12)),
                Padding(
                  padding: const EdgeInsets.all(0.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Container(
                          height: screenHeight * 0.065,
                          child: MomentumBuilder(
                            controllers: [AuthController],
                            builder: (context, snapshot) {
                              var authModel = snapshot<AuthModel>();
                              var authController = authModel.controller;
                              return FlatButton(
                                color: waGreen,
                                onPressed: () async {
                                  if (_formKey.currentState.validate()) {
                                    var email = _emailController.text.trim();
                                    var password =
                                        _passwordController.text.trim();
                                    var ref = _referralController.text.trim();
                                    Flushbar(
                                      message: "Processing",
                                      duration: Duration(seconds: 2),
                                    )..show(context);
                                    var result = await authController.register(
                                        email: email,
                                        password: password,
                                        ref: ref);
                                    if (result) {
                                      router.Router.goto(context, Home);
                                      print("success");
                                    } else {
                                      print(result);
                                      Flushbar(
                                        message: "Error in logging in!",
                                        duration: Duration(seconds: 2),
                                      )..show(context);
                                    }
                                  }
                                  print("login page login");
                                },
                                child: authModel.isLoading
                                    ? CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                Colors.black),
                                      )
                                    : Text(
                                        "LOGIN",
                                        style: TextStyle(),
                                      ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
