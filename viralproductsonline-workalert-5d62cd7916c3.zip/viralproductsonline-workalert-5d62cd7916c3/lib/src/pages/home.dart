import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:momentum/momentum.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:workalert/src/common/colors.dart';
import 'package:workalert/src/components/auth/index.dart';
import 'package:workalert/src/components/keywords/index.dart';
import 'package:workalert/src/components/rss/index.dart';
import 'package:workalert/src/services/pushNotification.dart';
import 'package:workalert/src/widgets/index.dart';
import 'package:workalert/src/widgets/logo.dart';
import 'package:momentum/src/momentum_router.dart' as router;
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';
import 'index.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends MomentumState<Home> with RelativeScale {
  bool isLoading = true;
  @override
  void didChangeDependencies() {
    initRelativeScaler(context);
    super.didChangeDependencies();
  }

  PushNotifications _pushNotifications = PushNotifications();
  @override
  void initMomentumState() async {
    var controller = Momentum.controller<KeywordsController>(context);
    await controller.getKeyWords();
    var rssController = Momentum.controller<RssController>(context);
    var authController = Momentum.controller<AuthController>(context);
    await authController.getUser();
    Map<String, String> keywords = {};

    await Firebase.initializeApp();
    List<String> keyWordsList = [];
    List<Map> AllKeywordslisttoupdate = [];
    List<Map> InitialList = [];
    DocumentSnapshot doc = await FirebaseFirestore.instance
        .collection("main")
        .doc(authController.model.email)
        .get();
    if (doc.exists && doc.data()['keywords'] != null) {
      for (int j = 0; j < doc.data()['keywords'].length; j++) {
        keyWordsList.add(doc.data()['keywords'][j]['keyword']);
        InitialList.add(doc.data()['keywords'][j]);
      }
    }
    for (var i in controller.model.keywordsAndPlanData.keywords) {
      keywords[i.keyword] = i.rss;
      if (keyWordsList.contains(i.keyword)) {
        int index = keyWordsList.indexOf(i.keyword);
        AllKeywordslisttoupdate.add(InitialList[index]);
      } else {
        AllKeywordslisttoupdate.add({"keyword": i.keyword, "rss": i.rss});
      }
    }
    if (AllKeywordslisttoupdate.isNotEmpty) {
      _pushNotifications.configureNotifcations().then((value) {
        if (value) {
          _pushNotifications.saveDeviceToken(
              authController.model.email, AllKeywordslisttoupdate);
        }
      });
    }
    await rssController.forceUpdateJobs(keywords);
    await rssController.startFetching(keywords);
    setState(() {
      isLoading = false;
    });
    super.initMomentumState();
  }

  GlobalKey<ScaffoldState> _drawerKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return RouterPage(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        key: _drawerKey,
        drawer: Drawer(
          child: Container(
            color: waGrey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(
                      top: sy(50), bottom: sy(20), left: sy(15)),
                  child: Logo(
                    fontSize: sy(30),
                  ),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Divider(
                      color: Colors.white,
                      thickness: 1,
                    ),
                    InkWell(
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text(
                          "Privacy Policy",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: sy(15)),
                        ),
                      ),
                      onTap: () async {
                        router.Router.goto(context, PrivacyPloicy);
                      },
                    ),
                    InkWell(
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text(
                          "Logout",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: sy(15)),
                        ),
                      ),
                      onTap: () async {
                        var controller =
                            Momentum.controller<AuthController>(context);
                        print(controller.model.referral);
                        await controller.logout(context);
                      },
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
        appBar: AppBar(
          leading: IconButton(
              icon: Icon(
                Icons.menu,
                color: waGreen,
              ),
              onPressed: () => _drawerKey.currentState.openDrawer()),
          backgroundColor: waGrey,
          title: Logo(),

          //   actions: [

          //   ],
        ),
        body: Column(
          children: [
            SizedBox(height: sy(14)),
            Expanded(
              child: Container(
                child: MomentumBuilder(
                  controllers: [
                    KeywordsController,
                    RssController,
                    AuthController
                  ],
                  builder: (context, snapshot) {
                    var keywordModel = snapshot<KeywordsModel>();
                    var keywordData = keywordModel.keywordsAndPlanData;
                    var authModel = snapshot<AuthModel>();
                    var rssModel = snapshot<RssModel>();
                    if (keywordData == null ||
                        keywordModel.isLoading ||
                        isLoading) {
                      return Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(waGreen),
                        ),
                      );
                    }
                    var keywords = keywordData.keywords ?? [];
                    return LiquidPullToRefresh(
                      backgroundColor: waGreen,
                      color: Colors.black,
                      showChildOpacityTransition: false,
                      onRefresh: () async {
                        var controller =
                            Momentum.controller<KeywordsController>(context);
                        await controller.getKeyWords();
                        var rssController =
                            Momentum.controller<RssController>(context);
                        var authController =
                            Momentum.controller<AuthController>(context);
                        await authController.getUser();
                        Map<String, String> keywords = {};
                        await Firebase.initializeApp();
                        List<String> keyWordsList = [];
                        List<Map> AllKeywordslisttoupdate = [];
                        List<Map> InitialList = [];
                        DocumentSnapshot doc = await FirebaseFirestore.instance
                            .collection("main")
                            .doc(authController.model.email)
                            .get();
                        if (doc.exists && doc.data()['keywords'] != null) {
                          for (int j = 0;
                              j < doc.data()['keywords'].length;
                              j++) {
                            keyWordsList
                                .add(doc.data()['keywords'][j]['keyword']);
                            InitialList.add(doc.data()['keywords'][j]);
                          }
                        }
                        for (var i
                            in controller.model.keywordsAndPlanData.keywords) {
                          keywords[i.keyword] = i.rss;
                          if (keyWordsList.contains(i.keyword)) {
                            int index = keyWordsList.indexOf(i.keyword);
                            AllKeywordslisttoupdate.add(InitialList[index]);
                          } else {
                            AllKeywordslisttoupdate.add(
                                {"keyword": i.keyword, "rss": i.rss});
                          }
                        }
                        _pushNotifications.saveDeviceToken(
                            authController.model.email,
                            AllKeywordslisttoupdate);
                        await rssController.forceUpdateJobs(keywords);

                        await rssController.startFetching(keywords);
                      },
                      child: ListView.separated(
                        itemCount: keywords.length + 1,
                        itemBuilder: (context, index) {
                          if (index == keywords.length) {
                            if (authModel.userData.referralPoints + 1 >
                                keywords.length) {
                              return AddKeyWord();
                            } else {
                              return Container();
                            }
                          } else {
                            return KeyWord(
                              name: keywords[index].keyword,
                              count: rssModel.itemCount[keywords[index].keyword]
                                  ?.toString(),
                              keyword: keywords[index],
                            );
                          }
                        },
                        separatorBuilder: (context, index) =>
                            SizedBox(height: sy(10)),
                      ),
                    );
                  },
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(sy(18)),
              child: Text(
                "Get More Keywords by Referring Friends",
                style: TextStyle(color: waGreen),
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18.0, 0.0, 18.0, 0.0),
                    child: Container(
                      height: screenHeight * 0.065,
                      child: FlatButton(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8)),
                        color: waGreen,
                        onPressed: () {
                          router.Router.goto(context, Referral);
                        },
                        child: Text("Refer To Friends"),
                      ),
                    ),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
