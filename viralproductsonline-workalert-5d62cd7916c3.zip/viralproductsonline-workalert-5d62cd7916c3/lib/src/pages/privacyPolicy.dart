import 'package:flutter/material.dart';
import 'package:momentum/momentum.dart';
import 'package:workalert/src/common/colors.dart';
import 'package:workalert/src/widgets/logo.dart';

class PrivacyPloicy extends StatelessWidget {
  const PrivacyPloicy({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RouterPage(
      onWillPop: () async {
        Router.pop(context);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: waGrey,
          title: Logo(),
        ),
        body: Padding(
            padding: const EdgeInsets.all(15.0),
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    H(t1),
                    H1(t2),
                    H(t3),
                    H1(t4),
                    H2(t5),
                    H(t6),
                    H2(t7),
                    H(t8),
                    H2(t9),
                    H(t10),
                    H2(t11),
                    H(t12),
                    H1(t13),
                    H(t14),
                    H1(t15),
                    H(t16),
                    H2(t17),
                    H(t18),
                    H2(t19),
                    H(t20),
                    H1(t21),
                    H2(t22),
                    H(t23),
                    H2(t24),
                    H(t25),
                    H2(t26),
                    H(t27),
                    H1(t28),
                    H(t29),
                    H2(t30),
                    H(t31),
                    H2(t32),
                    H(t33),
                    H2(t34),
                    H(t35),
                    H2(t36),
                    H(t37),
                    H2(t38),
                    H(t39),
                    H2(t40),
                    H(t41),
                    H2(t42),
                    H(t43),
                    H2(t44),
                    H(t45),
                    H2(t46),
                    H(t47),
                    H2(t48),
                    H(t49),
                    H1(t50),
                    H2(t51),
                    H(t52),
                    H2(t53),
                    H(t54),
                    H2(t55),
                    H(t56),
                    H2(t57),
                    H(t58),
                    H2(t59),
                    H(t60),
                    H2(t61),
                    H(t62),
                    H1(t63),
                    H2(t64),
                    H(t65),
                    H2(t66),
                    H(t67),
                    H2(t68),
                    H(t69),
                    H2(t70),
                    H(t71),
                    H2(t72),
                    H(t73),
                    H2(t74),
                    H(t75),
                    H2(t76),
                    H(t77),
                    H2(t78),
                    H(t79),
                    H2(t80),
                    H(t81),
                    H2(t82),
                    H(t83),
                    H2(t84),
                    H(t85),
                  ],
                ),
              ),
            )),
      ),
    );
  }
}

class H1 extends StatelessWidget {
  final String title;
  H1(this.title);

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: TextStyle(color: Colors.white, fontSize: 20),
    );
  }
}

class H2 extends StatelessWidget {
  final String title;
  H2(this.title);

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: TextStyle(color: Colors.white, fontSize: 17),
    );
  }
}

class H extends StatelessWidget {
  final String title;
  H(this.title);

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: TextStyle(color: Colors.white60, fontSize: 15),
    );
  }
}

String t1 = "This App collects some Personal Data from its Users. ";
String t2 = "Owner and Data Controller Types of Data collected ";
String t3 =
    "Among the types of Personal Data that this App collects, by itself or through third parties, there are: Cookies; Usage Data; email address; first name/n.Complete details on each type of Personal Data collected are provided in the dedicated sections of this privacy policy or by specific explanation texts displayed prior to the Data collection/n. Personal Data may be freely provided by the User, or, in case of Usage Data, collected automatically when using this App/n. Unless specified otherwise, all Data requested by this App is mandatory and failure to provide this Data may make it impossible for this App to provide its services. In cases where this App specifically states that some Data is not mandatory, Users are free not to communicate this Data without consequences to the availability or the functioning of the Service/n. Users who are uncertain about which Personal Data is mandatory are welcome to contact the Owner. Any use of Cookies – or of other tracking tools – by this App or by the owners of third-party services used by this App serves the purpose of providing the Service required by the User, in addition to any other purposes described in the present document and in the Cookie Policy, if available/n. Users are responsible for any third-party Personal Data obtained, published or shared through this App and confirm that they have the third party's consent to provide the Data to the Owner. ";
String t4 = "Mode and place of processing the Data";
String t5 = "Methods of processing ";
String t6 =
    "The Owner takes appropriate security measures to prevent unauthorized access, disclosure, modification, or unauthorized destruction of the Data. The Data processing is carried out using computers and/or IT enabled tools, following organizational procedures and modes strictly related to the purposes indicated. In addition to the Owner, in some cases, the Data may be accessible to certain types of persons in charge, involved with the operation of this App (administration, sales, marketing, legal, system administration) or external parties (such as third-party technical service providers, mail carriers, hosting providers, IT companies, communications agencies) appointed, if  necessary, as Data Processors by the Owner. The updated list of these parties may be requested from the Owner at any time. ";
String t7 = "Legal basis of processing";

String t8 =
    "The Owner may process Personal Data relating to Users if one of the following applies:/n Users have given their consent for one or more specific purposes. Note: Under some legislations the Owner may be allowed to process Personal Data until the User objects to such processing (“opt-out”), without having to rely on consent or any other of the following legal bases. This, however, does not apply, whenever the processing of Personal Data is subject to European data protection law; provision of Data is necessary for the performance of an agreement with the User and/or for any pre-contractual obligations thereof; processing is necessary for compliance with a legal obligation to which the Owner is subject; processing is related to a task that is carried out in the public interest or in the exercise of official authority vested in the Owner; processing is necessary for the purposes of the legitimate interests pursued by the Owner or by a third party. In any case, the Owner will gladly help to clarify the specific legal basis that applies to the processing, and in particular whether the provision of Personal Data is a statutory or contractual requirement, or a requirement necessary to enter into a contract. ";

String t9 = "Place";
String t10 =
    "The Data is processed at the Owner's operating offices and in any other places where the parties involved in the processing are located. Depending on the User's location, data transfers may involve transferring the User's Data to a country other than their own. To find out more about the place of processing of such transferred Data, Users can check the section containing details about the processing of Personal Data. Users are also entitled to learn about the legal basis of Data transfers to a country outside the European Union or to any international organization governed by public international law or set up by two or more countries, such as the UN, and about the security measures taken by the Owner to safeguard their Data. If any such transfer takes place, Users can find out more by checking the relevant sections of this document or inquire with the Owner using the information provided in the contact session ";

String t11 = "Retention time";

String t12 =
    "Personal Data shall be processed and stored for as long as required by the purpose they have been collected for. Therefore: Personal Data collected for purposes related to the performance of a contract between the Owner and the User shall be retained until such contract has been fully performed. Personal Data collected for the purposes of the Owner’s legitimate interests shall be retained as long as needed to fulfill such purposes. Users may find specific information regarding the legitimate interests pursued by the Owner within the relevant sections of this document or by contacting the Owner. The Owner may be allowed to retain Personal Data for a longer period whenever the User has given consent to such processing, as long as such consent is not withdrawn. Furthermore, the Owner may be obliged to retain Personal Data for a longer period whenever required to do so for the performance of a legal obligation or upon order of an authority. Once the retention period expires, Personal Data shall be deleted. Therefore, the right to access, the right to erasure, the right to rectification and the right to data portability cannot be enforced after expiration of the retention period. ";

String t13 = "The purposes of processing";

String t14 =
    "The Data concerning the User is collected to allow the Owner to provide its Services, as well as for the following purposes: Analytics, Contacting the User and Registration and authentication. Users can find further detailed information about such purposes of processing and about the specific Personal Data used for each purpose in the respective sections of this document";

String t15 = "Detailed information on the processing of Personal Data";

String t16 =
    "Personal Data is collected for the following purposes and using the following services: ";

String t17 = "Analytics";

String t18 =
    "The services contained in this section enable the Owner to monitor and analyze web traffic and can be used to keep track of User behavior. ";
String t19 = "Google Analytics (Google LLC) ";

String t20 =
    "Google Analytics is a web analysis service provided by Google LLC (“Google”). Google utilizes the Data collected to track and examine the use of this App, to prepare reports on  its activities and share them with other Google services. Google may use the Data collected to contextualize and personalize the ads of its own advertising network. Personal Data collected: Cookies; Usage Data. Place of processing: United States – Privacy Policy – Opt Out. Privacy Shield participant. ";

String t21 = "Contacting the User ";

String t22 = "Contact form (this App)";

String t23 =
    "By filling in the contact form with their Data, the User authorizes this App to use these details to reply to requests for information, quotes or any other kind of request as indicated by the form’s header. Personal Data collected: email address. ";
String t24 = "Registration and authentication";
String t25 =
    "By registering or authenticating, Users allow this App to identify them and give them access to dedicated services. Depending on what is described below, third parties may provide registration and authentication services. In this case, this App will be able to access some Data, stored by these third-party services, for registration or identification purposes.";

String t26 = "Direct registration (this App) ";

String t27 =
    "The User registers by filling out the registration form and providing the Personal Data directly to this App. Personal Data collected: email address; first name";

String t28 = "The rights of Users";

String t29 =
    "Users may exercise certain rights regarding their Data processed by the Owner. In particular, Users have the right to do the following: ";
String t30 = "Withdraw their consent at any time.";

String t31 =
    "Users have the right to withdraw consent where they have previously given their consent to the processing of their Personal Data.";
String t32 = "Object to processing of their Data";
String t33 =
    "Users have the right to object to the processing of their Data if the processing is carried out on a legal basis other than consent. Further details are provided in the dedicated section below.";

String t34 = "Access their Data";

String t35 =
    "Users have the right to learn if Data is being processed by the Owner, obtain disclosure regarding certain aspects of the processing and obtain a copy of the  Data undergoing processing";

String t36 = "Verify and seek rectification";

String t37 =
    "Users have the right to verify the accuracy of their Data and ask for it to be updated or corrected.";
String t38 = "Restrict the processing of their Data";
String t39 =
    "Users have the right, under certain circumstances, to restrict the processing of their Data. In this case, the Owner will not process their Data for any purpose other than storing it.";

String t40 = "Have their Personal Data deleted or otherwise removed";

String t41 =
    " Users have the right, under certain circumstances, to obtain the erasure of their Data from the Owner. ";

String t42 =
    "Receive their Data and have it transferred to another controller.";

String t43 =
    "Users have the right to receive their Data in a structured, commonly used and machine readable format and, if technically feasible, to have it transmitted to another controller without any hindrance. This provision is applicable provided that the Data is processed by automated means and that the processing is based on the User's consent, on a contract which the User is part of or on pre-contractual obligations thereof.";

String t44 = "Lodge a complaint";

String t45 =
    "Users have the right to bring a claim before their competent data protection authority.";

String t46 = "Details about the right to object to processing ";

String t47 =
    "Where Personal Data is processed for a public interest, in the exercise of an official authority vested in the Owner or for the purposes of the legitimate interests pursued by the Owner, Users may object to such processing by providing a ground related to their particular situation to justify the objection. Users must know that, however, should their Personal Data be processed for direct marketing purposes, they can object to that processing at any time without providing any justification. To learn, whether the Owner is processing Personal Data for direct marketing purposes, Users may refer to the relevant sections of this document. ";

String t48 = "How to exercise these rights ";

String t49 =
    "Any requests to exercise User rights can be directed to the Owner through the contact details provided in this document. These requests can be exercised free of charge and will be addressed by the Owner as early as possible and always within one month. ";
String t50 = "Additional information about Data collection and processing";

String t51 = " Legal action ";

String t52 =
    "The User's Personal Data may be used for legal purposes by the Owner in Court or in the stages leading to possible legal action arising from improper use of this App or the related Services. The User declares to be aware that the Owner may be required to reveal personal data upon request of public authorities. ";

String t53 = "Additional information about User's Personal Data";

String t54 =
    "In addition to the information contained in this privacy policy, this App may provide the User with additional and contextual information concerning particular Services or the collection and processing of Personal Data upon request. ";
String t55 = "System logs and maintenance";

String t56 =
    "For operation and maintenance purposes, this App and any third-party services may collect files that record interaction with this App (System logs) use other Personal Data (such as the IP Address) for this purpose. ";
String t57 = "Information not contained in this policy ";

String t58 =
    "More details concerning the collection or processing of Personal Data may be requested from the Owner at any time. Please see the contact information at the beginning of this document. ";
String t59 = "How “Do Not Track” requests are handled ";

String t60 =
    "This App does not support “Do Not Track” requests. To determine whether any of the third-party services it uses honor the “Do Not Track” requests, please read their privacy policies. ";

String t61 = "Changes to this privacy policy ";

String t62 =
    "The Owner reserves the right to make changes to this privacy policy at any time by giving notice to its Users on this page and possibly within this App and/or - as far as technically and legally feasible - sending a notice to Users via any contact information available to the Owner. It is strongly recommended to check this page often, referring to the date of the last modification listed at the bottom. Should the changes affect processing activities performed on the basis of the User’s consent, the Owner shall collect new consent from the User, where required.";

String t63 = "Definitions and legal references";

String t64 = "Personal Data (or Data) ";

String t65 =
    "Any information that directly, indirectly, or in connection with other information — including a personal identification number — allows for the identification or identifiability of a natural person";
String t66 = "Usage Data";

String t67 =
    "Information collected automatically through this App (or third-party services employed in this App), which can include: the IP addresses or domain names of the computers utilized by the Users who use this App, the URI addresses (Uniform Resource Identifier), the time of the request, the method utilized to submit the request to the server, the size of the file received in response, the numerical code indicating the status of the server's answer (successful outcome, error, etc.), the country of origin, the features of the browser and the operating system utilized by the User, the various time details per visit (e.g., the time spent on each page within the App) and the details about the path followed within the App with special reference to the sequence of pages visited, and other parameters about the device operating system and/or the User's IT environment. ";

String t68 = "User";

String t69 =
    "The individual using this App who, unless otherwise specified, coincides with the Data Subject. ";
String t70 = "Data Subject";
String t71 = "The natural person to whom the Personal Data refers. ";
String t72 = "Data Processor (or Data Supervisor) ";
String t73 =
    "The natural or legal person, public authority, agency or other body which processes Personal Data on behalf of the Controller, as described in this privacy policy. ";
String t74 = "Data Controller (or Owner) ";
String t75 =
    "The natural or legal person, public authority, agency or other body which, alone or jointly with others, determines the purposes and means of the processing of Personal Data, including the security measures concerning the operation and use of this App. The Data Controller, unless otherwise specified, is the Owner of this App. ";
String t76 = "This App";
String t77 =
    "The means by which the Personal Data of the User is collected and processed.";
String t78 = "Service ";
String t79 =
    "The service provided by this App as described in the relative terms (if available) and on this site/application. ";

String t80 = "European Union (or EU) ";

String t81 =
    "Unless otherwise specified, all references made within this document to the European Union include all current member states to the European Union and the European Economic Area. ";
String t82 = "Cookies";

String t83 = "Small sets of data stored in the User's device. ";

String t84 = "Legal information";

String t85 =
    "This privacy statement has been prepared based on provisions of multiple legislations, including Art. 13/14 of Regulation (EU) 2016/679 (General Data Protection Regulation). This privacy policy relates solely to this App, if not stated otherwise within this document.";
