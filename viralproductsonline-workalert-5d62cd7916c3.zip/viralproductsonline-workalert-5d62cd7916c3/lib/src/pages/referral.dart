import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:momentum/momentum.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:workalert/src/common/colors.dart';
import 'package:workalert/src/components/auth/index.dart';
import 'package:workalert/src/pages/index.dart';
import 'package:workalert/src/widgets/index.dart';
import 'package:momentum/src/momentum_router.dart' as router;

class Referral extends StatefulWidget {
  @override
  _ReferralState createState() => _ReferralState();
}

class _ReferralState extends MomentumState<Referral> with RelativeScale {
  TextEditingController _refController;
  @override
  void didChangeDependencies() {
    initRelativeScaler(context);
    super.didChangeDependencies();
  }

  @override
  void initMomentumState() async {
    _refController = TextEditingController();

    super.initMomentumState();
  }

  @override
  Widget build(BuildContext context) {
    return RouterPage(
      onWillPop: () async {
        router.Router.pop(context);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: waGrey,
          centerTitle: true,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
            onPressed: () {
              router.Router.goto(context, Home);
            },
          ),
          title: Text(
            'REFER A FRIEND',
            style: TextStyle(color: Colors.white, fontSize: sx(16)),
          ),
          actions: [
            Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Logo(),
              ),
            ),
          ],
        ),
        body: MomentumBuilder(
          controllers: [AuthController],
          builder: (context, snapshot) {
            var authModel = snapshot<AuthModel>();
            print(authModel.userData);
            if (authModel.userData?.token == null) {
              return Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation(waGreen),
                ),
              );
            }

            return Column(
              children: [
                SizedBox(
                  height: sy(10),
                ),
                InkWell(
                  onTap: () {
                    Clipboard.setData(
                      ClipboardData(text: authModel.referral),
                    );
                    Flushbar(
                      message: "Copied referral code to clipboard!",
                      duration: Duration(seconds: 2),
                    )..show(context);
                  },
                  child: ReferListItem(
                    title: 'Your Referral Code',
                    child: Text(
                      authModel.referral,
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
                // InkWell(
                //   onTap: () {
                //     Clipboard.setData(
                //       ClipboardData(
                //           text:
                //               'https://workalert.mind2matter.co?ref=${authModel.referral}'),
                //     );
                //     Flushbar(
                //       message: "Copied referral link to clipboard!",
                //       duration: Duration(seconds: 2),
                //     )..show(context);
                //   },
                //   child: ReferListItem(
                //     title: 'Your Referral Link',
                //     child: Text(
                //       'https://workalert.mind2matter.co?ref=${authModel.referral}',
                //       style: TextStyle(color: Colors.white),
                //     ),
                //   ),
                // ),
                // // Form(
                //   child: ReferListItem(
                //     title: 'Referral Code',
                //     child: TextFormField(
                //       controller: _refController,
                //       style: TextStyle(color: Colors.white),
                //       decoration: InputDecoration(
                //           border: InputBorder.none,
                //           isDense: true,
                //           isCollapsed: true,
                //           hintText: 'Enter Someone Else\'s Referral Code',
                //           hintStyle:
                //               TextStyle(color: Colors.grey.withOpacity(0.5))),
                //     ),
                //   ),
                // ),
                Expanded(
                  child: Container(),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          'Total Referrals: ' +
                              authModel.userData.referralPoints.toString(),
                          style: TextStyle(color: Colors.white),
                        ),
                        Text(
                          'Refer Your Friends To Get more Keyword Feeds',
                          style: TextStyle(color: waGreen),
                        ),
                        SizedBox(
                          height: sy(20),
                        )
                      ],
                    )
                  ],
                )
              ],
            );
          },
        ),
      ),
    );
  }
}
