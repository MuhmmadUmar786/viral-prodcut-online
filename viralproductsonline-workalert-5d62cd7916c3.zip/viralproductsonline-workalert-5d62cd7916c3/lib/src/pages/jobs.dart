import 'dart:async';
import 'package:html/parser.dart' show parse;
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_html/style.dart';
import 'package:momentum/momentum.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webfeed/domain/rss_item.dart';
import 'package:workalert/src/common/colors.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:workalert/src/components/auth/index.dart';
import 'package:workalert/src/components/job/job.controller.dart';
import 'package:workalert/src/components/job/job.model.dart';
import 'package:workalert/src/components/rss/index.dart';
import 'package:workalert/src/services/TimeCalulator.dart';
import 'package:workalert/src/widgets/index.dart';
import 'package:momentum/src/momentum_router.dart' as router;
import 'package:flutter_native_admob/flutter_native_admob.dart';
import 'package:flutter_native_admob/native_admob_controller.dart';
import 'index.dart';
import 'package:firebase_admob/firebase_admob.dart';

class Jobs extends StatefulWidget {
  final int newjobscount;
  Jobs({this.newjobscount});
  @override
  _JobsState createState() => _JobsState();
}

class _JobsState extends State<Jobs> with RelativeScale {
  final _nativeAdController = NativeAdmobController();
  double _height = 0;

  StreamSubscription _subscription;
  @override
  void didChangeDependencies() {
    initRelativeScaler(context);
    super.didChangeDependencies();
  }

  bool _isenablelogout = false;

  var items;

  @override
  void initState() {
    _subscription = _nativeAdController.stateChanged.listen(_onStateChanged);
    _isenablelogout = false;
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await Future.delayed(Duration(seconds: 1));
      _isenablelogout = true;
    });
    setState(() {
      _isenablelogout = _isenablelogout;
    });
    super.initState();
  }

  void _onStateChanged(AdLoadState state) {
    switch (state) {
      case AdLoadState.loading:
        setState(() {
          _height = 0;
        });
        break;

      case AdLoadState.loadCompleted:
        setState(() {
          _height = 330;
        });
        break;

      default:
        break;
    }
  }

  @override
  void dispose() {
    _subscription.cancel();
    _nativeAdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RouterPage(
      onWillPop: () async {
        router.Router.pop(context);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: waGrey,
          title: Logo(),
          actions: [
            //   InkWell(
            //     child: Center(
            //       child: Padding(
            //         padding: const EdgeInsets.all(8.0),
            //         child: Text(
            //           "Logout",
            //           style: TextStyle(
            //               color: Colors.white, fontWeight: FontWeight.bold),
            //         ),
            //       ),
            //     ),
            //     onTap: _isenablelogout
            //         ? () async {
            //             var controller =
            //                 Momentum.controller<AuthController>(context);
            //             print(controller.model.referral);
            //             await controller.logout(context);
            //           }
            //         : null,
            //   )
          ],
        ),
        body: MomentumBuilder(
          controllers: [RssController, JobController],
          builder: (context, snapshot) {
            var jobModel = snapshot<JobModel>();
            var rssModel = snapshot<RssModel>();
            items = rssModel.jobsmap[jobModel.currentWord];
            return CustomWidget(
              jobModel: jobModel,
              items: items,
              height: _height,
              nativeAdController: _nativeAdController,
            );
          },
        ),
      ),
    );
  }
}

class CustomWidget extends StatefulWidget {
  const CustomWidget({
    Key key,
    @required this.jobModel,
    @required this.items,
    @required double height,
    @required NativeAdmobController nativeAdController,
  })  : _height = height,
        _nativeAdController = nativeAdController,
        super(key: key);
  final items;
  final JobModel jobModel;
  final double _height;
  final NativeAdmobController _nativeAdController;

  @override
  _CustomWidgetState createState() =>
      _CustomWidgetState(items == null ? 0 : items.length);
}

class _CustomWidgetState extends State<CustomWidget> {
  final int itemscount;
  _CustomWidgetState(this.itemscount);
  List<bool> _ismore = [];
  @override
  void initState() {
    super.initState();
    for (int j = 0; j < itemscount + 3; j++) {
      _ismore.add(false);
    }
  }

  static const String productUnitID = "ca-app-pub-8791277208325190/6345915335";
  static const String list1 = 'ca-app-pub-8791277208325190/2607826782';
  static const String list2 = 'ca-app-pub-8791277208325190/9135730207';
  static const String list3 = 'ca-app-pub-8791277208325190/2520196871';
  static const String list4 = 'ca-app-pub-8791277208325190/7580951863';
  static const String list5 = 'ca-app-pub-8791277208325190/1500782767';
  static const String list6 = 'ca-app-pub-8791277208325190/3922916067';
  static const String list7 = 'ca-app-pub-8791277208325190/5408238183';
  static const String list8 = "ca-app-pub-8791277208325190/1800165669";
  static const String list9 = "ca-app-pub-8791277208325190/3048818099";
  static List<String> adUnits = [
    productUnitID,
    list1,
    list2,
    list3,
    list4,
    list5,
    list6,
    list7,
    list8,
    list9
  ];

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: InkWell(
                  onTap: () {
                    var rsscontroller =
                        Momentum.controller<RssController>(context);
                    rsscontroller.updateCount(widget.jobModel.currentWord, 0);
                    router.Router.pop(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: waGreen,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Back",
                          style: TextStyle(color: waGreen),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Text("Keyword: " + widget.jobModel.currentWord,
                    style: TextStyle(color: Colors.white)),
              ),
              Expanded(child: Container()),
            ],
          ),
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) {
              var item = widget.items[index];
              print("printing job title heer ${item.title}");
              var budget;
              var hourlyrange;
              var document = parse(item.content);
              List<String> list1 = document
                  .getElementsByTagName('body')
                  .first
                  .text
                  .split("Budget");
              String shortdata = "";
              if (list1.isNotEmpty) {
                shortdata = list1.first;
              }
              if (list1.length > 1) {
                List<String> list2 = list1[1].split("Posted On:");
                if (list2.length > 1) {
                  budget = list2.first;
                }
              }
              List<String> list3 = document
                  .getElementsByTagName('body')
                  .first
                  .text
                  .split("Hourly Range");
              if (list3.length > 1) {
                List<String> list4 = list3[1].split("Posted On:");
                if (list4.length > 1) {
                  hourlyrange = list4.first;
                }
              }

              return Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      decoration: BoxDecoration(
                          border: index < (widget.jobModel.newJobCount ?? 0)
                              ? Border.all(color: waGreen)
                              : null),
                      child: Card(
                        color: waGrey,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      postedago(item.content),
                                      style: TextStyle(color: Colors.white60),
                                    ),
                                    if (budget != null)
                                      Text(
                                        "Budget$budget",
                                        style: TextStyle(color: Colors.white60),
                                      ),
                                    if (hourlyrange != null)
                                      Text(
                                        "Hourly Range$hourlyrange",
                                        style: TextStyle(color: Colors.white60),
                                      ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text(
                                  item.title,
                                  style: TextStyle(
                                    color: Colors.white60,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              _ismore.isEmpty || _ismore[index]
                                  ? Html(
                                      onLinkTap: (url) async {
                                        if (await canLaunch(url)) {
                                          await launch(url);
                                        } else {
                                          throw 'Could not launch $url';
                                        }
                                      },
                                      data: item.content,
                                      style: {
                                        "html": Style(
                                          color: Colors.white60,
                                        ),
                                        "a": Style(
                                          after: "         ",
                                          alignment: Alignment.bottomCenter,
                                          fontWeight: FontWeight.bold,
                                          fontSize: FontSize.large,
                                          textDecoration: TextDecoration.none,
                                          color: waGreen,
                                        ),
                                        "b": Style(
                                          color: Colors.white60,
                                        ),
                                      },
                                    )
                                  : Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            shortdata,
                                            maxLines: 3,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                                color: Colors.white60),
                                          ),
                                          GestureDetector(
                                            child: Text(
                                              "more",
                                              style: TextStyle(color: waGreen),
                                            ),
                                            onTap: () {
                                              _ismore[index] = true;
                                              setState(() {
                                                _ismore = _ismore;
                                              });
                                            },
                                          )
                                        ],
                                      ),
                                    )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  index != 0 && index % 2 != 0
                      ? Container(
                          height: widget._height,
                          child: NativeAdmob(
                            adUnitID: adUnits[index % 10],
                            controller: widget._nativeAdController,
                            loading: Container(),
                          ),
                        )
                      : SizedBox.shrink()
                ],
              );
            },
            childCount: widget.items == null ? 0 : widget.items.length,
          ),
        )
      ],
    );
  }
}
