import 'package:flutter/rendering.dart';

const Color waGreen = Color(0xFF09EE6A);
const Color waGrey = Color(0xFF1A1A1A);
