import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:workalert/src/services/notificationplugin.dart';

class PushNotifications {
  Future<bool> configureNotifcations() async {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (message.notification != null) {
        print("Arrived here");
        notificationPlugin.setOnNotificationClick(() {
          print("DONE");
        });
        notificationPlugin.showNotification(
            message.notification.title, message.notification.body);
      }
    });
    return true;
  }

  saveDeviceToken(String email, List<Map<dynamic, dynamic>> alllist) async {
    await Firebase.initializeApp();
    String fcmToken = await FirebaseMessaging.instance.getToken();
    if (fcmToken != null) {
      await FirebaseFirestore.instance.collection("main").doc(email).set({
        "keywords": alllist,
        "fcm": fcmToken,
        "platform": Platform.operatingSystem
      }, SetOptions(merge: true));
    }
    // Save it to Firestore
  }
}
