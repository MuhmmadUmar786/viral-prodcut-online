import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:webfeed/domain/rss_feed.dart';

import 'package:webfeed/domain/rss_item.dart';
import 'package:workalert/src/data/index.dart';
import 'package:workalert/src/services/TimeCalulator.dart';
import 'package:workalert/src/services/client_db.dart';
import 'package:workalert/src/services/jobs_services.dart';
import 'package:workalert/src/services/notificationplugin.dart';
import 'package:workmanager/workmanager.dart';

void callbackDispatcher() {
  Workmanager.executeTask((task, inputData) async {
    await updateJobs();
    return true;
  });
}

void newcallbackDispatcher() {
  Workmanager.executeTask((task, inputData) async {
    http.Response response = await http.get(
        "https://www.upwork.com/ab/feed/topics/rss?securityToken=8baed4433e9040ccc9eee5570e944087950814ad4695ac5fbf241c383a993f793a516ce4abc1902a408aa4e7588438e643885947180a78b5edaa9e7364d48799&userUid=1286150873466073088&orgUid=1286150873470267393");
    if (response.statusCode == 200) {
      var rssFeed = RssFeed.parse(response.body);
      ClientDB cl = ClientDB();
      var items = rssFeed.items;
      int timeoffirstjob =
          jobtime(items.first.content.value).millisecondsSinceEpoch;
      int lastjobtime = 0;
      // await cl.getlastjobtime();
      if (timeoffirstjob > lastjobtime) {
        await notificationPlugin
            .setListenerForLowerVersions(onNotificationInLowerVersions);
        notificationPlugin.setOnNotificationClick(onNotificationClick);
        // notificationPlugin.showNotification();
      }
    }
    return true;
  });
}

onNotificationInLowerVersions(ReceivedNotification receivedNotification) {
  print('Notification Received ${receivedNotification.id}');
}

onNotificationClick(String payload) async {
  print("none");
}

Future<Timer> updateJobs() async {
  JobService jobService = JobService();
  await jobService.init();
  var timer = Timer.periodic(
    Duration(minutes: 1),
    (timer) async {
      var keywords = await jobService.getKeywords();
      var jobs = await jobService.getAllJobs();
      List<Jobs> newJobs = [];
      for (var keyword in keywords) {
        var items = await getData(keyword['url']);
        for (var item in items) {
          try {
            jobs.where((job) => job.title == item.title);
          } on StateError {
            newJobs.add(
              Jobs(
                  content: item.content.value,
                  keyword: keyword['name'],
                  title: item.title,
                  url: keyword['url']),
            );
            await jobService.updateCounter(keyword['name'], 1);
          }
        }
      }
      jobService.insertJobs(jobs);
      print("updated jobs");
    },
  );

  return timer;
}

Future<List<RssItem>> getData(String url) async {
  http.Response response = await http.get(url);
  if (response.statusCode == 200) {
    print("running main task");
    var rssFeed = RssFeed.parse(response.body);
    var items = rssFeed.items;
    return items;
  } else {
    return [];
  }
}
