import 'package:flutter/foundation.dart';
import 'package:momentum/momentum.dart';
import 'package:workalert/src/data/index.dart';
import 'package:http/http.dart' as http;

class Api extends MomentumService {
  // static const Uri baseUri = "https://workalert.mind2matter.co/api";
  final Uri baseUri = Uri.https('workalert.mind2matter.co', '/api');
  final String userAgent =
      'Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; SCH-I535 Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30';

  Future<RegisterData> register(
      {@required String email, @required String password, String ref}) async {
    var queryParams = {
      "email": email,
      "password": password,
      "password_confirmation": password,
    };

    if (ref != null || ref.isNotEmpty) {
      queryParams['ref'] = ref;
    }
    Uri uri = Uri.https(
        baseUri.authority, baseUri.path + '/mobile/register', queryParams);
    http.Response response = await http.post(uri, headers: {
      'User-Agent': userAgent,
    });

    if (response.statusCode < 400) {
      return registerDataFromJson(response.body);
    }

    throw Exception(response);
  }

  Future<LoginData> login(
      {@required String email, @required String password}) async {
    var queryParams = {
      "email": email,
      "password": password,
    };
    Uri uri = Uri.https(
        baseUri.authority, baseUri.path + '/mobile/login', queryParams);
    print(uri.toString());
    http.Response response = await http.post(uri, headers: {
      'User-Agent': userAgent,
    });

    if (response.statusCode < 400) {
      return loginDataFromJson(response.body);
    }

    throw Exception(response);
  }

  Future<http.Response> forgetPassword({
    @required String email,
  }) async {
    var queryParams = {
      "email": email,
    };
    Uri uri = Uri.https(
        baseUri.authority, baseUri.path + '/forgot-password', queryParams);
    print(uri.toString());
    http.Response response = await http.post(uri, headers: {
      'User-Agent': userAgent,
    });
    return response;
  }

  Future<UserData> getUser({@required String token}) async {
    Uri uri = Uri.https(baseUri.authority, baseUri.path + '/user');
    http.Response response = await http.get(uri, headers: {
      "Authorization": "Bearer $token",
      'User-Agent': userAgent,
    });

    if (response.statusCode < 400) {
      return userDataFromJson(response.body);
    }

    throw Exception(response);
  }

  Future<KeyWordData> storeKeyword(
      {@required String keyword,
      @required String rss,
      @required String token}) async {
    var queryParams = {
      "keyword": keyword,
      "rss": rss,
    };

    Uri uri =
        Uri.https(baseUri.authority, baseUri.path + '/keywords', queryParams);
    http.Response response = await http.post(uri, headers: {
      "Authorization": "Bearer $token",
      'User-Agent': userAgent,
    });

    if (response.statusCode < 400) {
      return keyWordDataFromJson(response.body);
    }

    throw Exception(response);
  }

  Future<KeywordsAndPlanData> getKeyWords({@required String token}) async {
    Uri uri = Uri.https(baseUri.authority, baseUri.path + '/keywords');
    http.Response response = await http.get(uri, headers: {
      "Authorization": "Bearer $token",
      'User-Agent': userAgent,
    });

    if (response.statusCode < 400) {
      return keywordsAndPlanDataFromJson(response.body);
    }

    throw Exception(response);
  }

  Future<KeywordsAndPlanData> deleteWord(
      {@required String token, @required int id}) async {
    Uri uri = Uri.https(baseUri.authority, baseUri.path + '/keywords/$id');
    http.Response response = await http.delete(uri, headers: {
      "Authorization": "Bearer $token",
      'User-Agent': userAgent,
    });

    if (response.statusCode < 400) {
      return keywordsAndPlanDataFromJson(response.body);
    }

    throw Exception(response);
  }
}
