import 'package:flutter/material.dart';
import 'package:momentum/momentum.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workalert/src/services/TimeCalulator.dart';

class ClientDB extends MomentumService {
  SharedPreferences _sharedPreferences;
  // Future<void> savelastjobtime(String content) async {
  //   DateTime d = jobtime(content);
  //   _sharedPreferences = await SharedPreferences.getInstance();
  //   _sharedPreferences.setInt("time", d.millisecondsSinceEpoch);
  //   return null;
  // }

  // Future<int> getlastjobtime() async {
  //   _sharedPreferences = await SharedPreferences.getInstance();
  //   int t = _sharedPreferences.getInt('time');
  //   return t;
  // }

  Future<SharedPreferences> getByInstance() async {
    _sharedPreferences ??= await SharedPreferences.getInstance();
    return _sharedPreferences;
  }

  static Future<SharedPreferences> getByContext(BuildContext context) async {
    var service = Momentum.service<ClientDB>(context);
    service._sharedPreferences ??= await SharedPreferences.getInstance();
    return service._sharedPreferences;
  }
}
