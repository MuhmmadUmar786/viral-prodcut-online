import 'package:html/parser.dart' show parse;
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:workalert/src/services/dateTimeConversion.dart';

DateTime jobtime(String jobcontent) {
  var posting;
  DateTime d;
  var document = parse(jobcontent);
  try {
    List<String> list1 =
        document.getElementsByTagName('body').first.text.split("Posted On: ");
    if (list1.length > 1) {
      List<String> list2 = list1[1].split("Category");
      if (list2.isNotEmpty) {
        posting = list2.first;
      }
    }
    if (posting != null) {
      List<String> words = posting.toString().split(" ");
      if (words.length == 5) {
        int month = monthFromString(words[0]);
        int date = int.parse((words[1].split(",")).first);
        int year = int.parse(words[2]);
        List<String> times = words[3].split(":");
        int hour = int.parse(times[0]);
        int minutes = int.parse(times[1]);
        d = DateTime.utc(year, month, date, hour, minutes);
      }
    }
  } catch (err) {
    d = DateTime.now().toUtc();
  }
  return d;
}

String postedago(String content) {
  DateTime d = jobtime(content);
  print("time pr $d");
  DateTime currenttime = DateTime.now().toUtc();
  print("time pr $currenttime");
  Duration duration = currenttime.difference(d);
  int days = duration.inDays;
  int hour = duration.inHours;
  int minutes = duration.inMinutes;
  String postedago;
  if (days > 30) {
    if (days % 30 == 0) {
      var month = (days / 30);
      int m = month.round();
      postedago = "Posted $m months ago";
    } else {
      var month = (days % 30);
      int m = month.round();
      postedago = "Posted $m months ago";
    }
  } else if (days > 0) {
    postedago = "Posted $days days ago";
  } else if (hour > 0) {
    postedago = "Posted $hour hours ago";
  } else if (minutes > 0) {
    postedago = "Posted $minutes minutes ago";
  } else {
    postedago = "Posted jsut now";
  }
  return postedago;
}
