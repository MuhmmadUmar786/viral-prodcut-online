import 'package:momentum/momentum.dart';
import 'package:sqflite/sqflite.dart';
import 'package:workalert/src/data/job.dart';

class JobService {
  Database db;
  int v = 1;
  Future init() async {
    db = await openDatabase('database.db', onCreate: (db, v) async {
      await db.execute(
          'CREATE TABLE Jobs (id INTEGER PRIMARY KEY, title TEXT, content TEXT, keyword TEXT, url TEXT)');
      await db.execute(
          'CREATE TABLE Counter (id INTEGER PRIMARY KEY, keyword TEXT, count INTEGER)');
      await db.execute(
          'CREATE TABLE Keywords (id INTEGER PRIMARY KEY, name TEXT, url TEXT)');
    });
  }

  Future insertJobs(List<Jobs> jobs) async {
    var batch = db.batch();
    for (var job in jobs) {
      batch.insert('Jobs', {
        'title': job.title,
        'content': job.content,
        'keyword': job.keyword,
        'url': job.url,
      });
    }
    await batch.commit();
  }

  Future deleteJobs(String keyword) async {
    print("deleting pressed");
    await db.rawDelete('DELETE FROM Jobs WHERE name = ?', ['Flutter']);
    var batch = db.batch();
    batch.delete('Jobs', where: 'keyword = ?', whereArgs: [keyword]);
    batch.commit();
    await deleteKeyword(keyword);
  }

  Future updateCounter(String keyword, [int count = 0]) async {
    await db.execute(
        'UPDATE Counter SET count = count + $count WHERE keyword = `$keyword`');
  }

  Future resetCounter(String keyword) async {
    await db.execute('UPDATE Counter SET count = 0 WHERE keyword = `$keyword`');
  }

  Future<int> getCount(String keyword) async {
    var res =
        await db.query('Counter', where: 'keyword = ?', whereArgs: [keyword]);
    return res.first['count'];
  }

  Future<List<Jobs>> fetchJobs(String keyword) async {
    var result = await db.query('Jobs',
        where: 'keyword = ?', whereArgs: [keyword], orderBy: 'id DESC');
    await resetCounter(keyword);
    return result.map((job) => Jobs.fromJson(job)).toList();
  }

  Future addKeyword(String name, String url) async {
    await db.insert('Keywords', {
      'name': name,
      'url': url,
    });
  }

  Future<List<Map<String, dynamic>>> getKeywords() async {
    var res = await db.query('Keywords');
    return res;
  }

  Future deleteKeyword(String name) async {
    await db.delete('Keywords', where: 'name = ?', whereArgs: [name]);
  }

  Future<List<Jobs>> getAllJobs() async {
    var result = await db.query('Jobs', orderBy: 'id DESC');

    return result.map((job) => Jobs.fromJson(job)).toList();
  }

  Future close() async => db.close();
}
