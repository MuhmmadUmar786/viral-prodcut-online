import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:momentum/momentum.dart';
import 'package:momentum/src/momentum_router.dart' as router;
import 'package:workalert/src/components/auth/index.dart';
import 'package:workalert/src/components/job/job.controller.dart';
import 'package:workalert/src/components/keywords/index.dart';
import 'package:workalert/src/components/rss/index.dart';
import 'package:workalert/src/pages/index.dart';
import 'package:workalert/src/services/api.dart';
import 'package:workalert/src/services/client_db.dart';
import 'package:workmanager/workmanager.dart';
import 'package:flutter_native_admob/flutter_native_admob.dart';
import 'package:firebase_core/firebase_core.dart';

import 'src/services/dispatcher.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  await Firebase.initializeApp();

  print("Handling a background message: ${message.messageId}");
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  // Workmanager.initialize(
  //     //callbackDispatcher,
  //     // The top level function, aka callbackDispatcher
  //     newcallbackDispatcher,
  //     isInDebugMode:
  //         false // If enabled it will post a notification whenever the task is running. Handy for debugging tasks
  //     );
  // // Workmanager.registerOneOffTask("1", "simpleTask");
  // // Periodic task registration
  // Workmanager.registerPeriodicTask(
  //   "2",
  //   "simplePeriodicTask",
  //   frequency: Duration(minutes: 15),
  // );
  runApp(momentum());
}

Momentum momentum() {
  return Momentum(
    restartCallback: main,
    key: UniqueKey(),
    child: WorkAlert(),
    controllers: [
      AuthController(),
      KeywordsController(),
      RssController(),
      JobController(),
    ],
    services: [
      ClientDB(),
      Api(),
      router.Router(
        [
          Landing(),
          Login(),
          Register(),
          Home(),
          Jobs(),
          Referral(),
          PrivacyPloicy(),
          ResetPassword()
        ],
      ),
    ],
    persistSave: (context, key, value) async {
      var sharedPref = await ClientDB.getByContext(context);
      var result = await sharedPref.setString(key, value);
      return result;
    },
    persistGet: (context, key) async {
      var sharedPref = await ClientDB.getByContext(context);
      var result = sharedPref.getString(key);
      return result;
    },
    onResetAll: (context, resetAll) async {
      var sharedPref = await ClientDB.getByContext(context);
      sharedPref.clear();
      try {} catch (e) {
        print(e);
      }
      resetAll(context);
    },
  );
}

class WorkAlert extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "WorkAlert",
      debugShowCheckedModeBanner: false,
      home: router.Router.getActivePage(context),
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.black,
        primaryColor: Colors.greenAccent,
        textTheme: GoogleFonts.robotoTextTheme(
          Theme.of(context).textTheme,
        ),
      ),
    );
  }
}
