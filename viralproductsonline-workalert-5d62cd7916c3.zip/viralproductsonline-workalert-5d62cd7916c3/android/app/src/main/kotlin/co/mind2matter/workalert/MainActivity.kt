package co.mind2matter.workalert

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
