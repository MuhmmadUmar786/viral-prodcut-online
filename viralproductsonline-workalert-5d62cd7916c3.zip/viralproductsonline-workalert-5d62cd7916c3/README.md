# Notes for development

## AdMob
1. Android App ID for AdMob ca-app-pub-8791277208325190~1044053001
2. iOS App ID for Admob ca-app-pub-8791277208325190~4728464374
3. Rewarded video between the Keyword page and the jobs page. Then native ads between job posts


## API

BASE URL: https://workalert.mind2matter.co/api or https://workalert.mind2matter.co/
